﻿namespace CarDealer.DTO.Export
{
    public class PartDto
    {
        public string Name { get; set; }

        public string Price { get; set; }
    }
}
﻿namespace FastFood.Web.ViewModels.Categories
{
    public class CategoryAllViewModel
    {
        public string Name { get; set; }
    }
}

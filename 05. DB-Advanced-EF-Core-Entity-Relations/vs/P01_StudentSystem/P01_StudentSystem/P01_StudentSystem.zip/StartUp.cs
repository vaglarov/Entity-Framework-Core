﻿namespace P01_StudentSystem
{
using System;
    class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

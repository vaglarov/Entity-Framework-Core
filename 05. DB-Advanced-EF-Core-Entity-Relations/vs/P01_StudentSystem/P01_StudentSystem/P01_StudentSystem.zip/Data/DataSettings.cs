﻿namespace P01_StudentSystem.Data
{
    static class DataSettings
    {
        public const string ConnectionString = @"Server=DESKTOP-OK0RAUD\SQLEXPRESS;Database=StudentSystem; Integrated Security = true;";
    }
}

﻿using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using P01_StudentSystem.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public class StudentSystemContext : DbContext
    {
        public StudentSystemContext()
        {
        }
        public StudentSystemContext(DbContextOptions options) 
            : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }

        public DbSet<Course> Courses { get; set; }

        public DbSet<Resource> Resources { get; set; }

        public DbSet<Homework> HomeworkSubmissions { get; set; }

        public DbSet<StudentCourse> StudentCourses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(Configuration.ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>(entity =>
            {
                entity
                .HasKey(e => e.StudentId);

                entity
                .Property(e => e.Name)
                .HasMaxLength(100)
                .IsRequired(true)
                .IsUnicode(true);

                entity
                .Property(e => e.PhoneNumber)
                .HasColumnType("char(10)")
                .IsRequired(false)
                .IsUnicode(false);

                entity
                .Property(e => e.RegisteredOn)
                .IsRequired(true)
                .HasDefaultValueSql("GETDATE()");

                entity
                .Property(e => e.Birthday)
                .IsRequired(false);

                entity
                .HasMany(e => e.HomeworkSubmissions)
                .WithOne(h => h.Student)
                .HasForeignKey(h => h.StudentId);
            });

            modelBuilder.Entity<Course>(entity =>
            {
                entity
                .HasKey(e => e.CourseId);

                entity
                .Property(e => e.Name)
                .HasMaxLength(80)
                .IsRequired(true)
                .IsUnicode(true);

                entity
                .Property(e => e.Description)
                .IsRequired(false)
                .IsUnicode(true);

                entity
                .Property(e => e.StartDate)
                .IsRequired(true);

                entity
                .Property(e => e.EndDate)
                .IsRequired(true);

                entity
                .Property(e => e.Price)
                .IsRequired(true);

                entity
                .HasMany(e => e.Resources)
                .WithOne(r => r.Course)
                .HasForeignKey(r => r.CourseId);

                entity
                .HasMany(e => e.HomeworkSubmissions)
                .WithOne(h => h.Course)
                .HasForeignKey(h => h.CourseId);
            });

            modelBuilder.Entity<Resource>(entity =>
            {
                entity.HasKey(e => e.ResourceId);

                entity
                .Property(e => e.Name)
                .HasMaxLength(50)
                .IsRequired(true)
                .IsUnicode(true);

                entity
                .Property(e => e.Url)
                .IsRequired(true)
                .IsUnicode(false);

                entity
                .HasOne(e => e.Course)
                .WithMany(c => c.Resources)
                .HasForeignKey(e => e.CourseId);

            });

            modelBuilder.Entity<Homework>(entity =>
            {
                entity.HasKey(e => e.HomeworkId);

                entity
                .Property(e => e.Content)
                .IsUnicode(false);

                entity
                .Property(e => e.SubmissionTime)
                .IsRequired(true);
            });

            modelBuilder.Entity<StudentCourse>(entity =>
            {
                entity
                .HasKey(e => new { e.StudentId, e.CourseId });

                entity
                .HasOne(e => e.Course)
                .WithMany(c => c.StudentsEnrolled)
                .HasForeignKey(e => e.CourseId);

                entity
                .HasOne(e => e.Student)
                .WithMany(s => s.CourseEnrollments)
                .HasForeignKey(e => e.StudentId);

            });
        }
    }
}

﻿namespace VaporStore.Data.Models.Enums
{
    public enum CadrType
    {
        Debit, 
        Credit
    }
}

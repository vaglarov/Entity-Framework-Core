﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-OK0RAUD\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}